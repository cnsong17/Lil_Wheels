/*******************************************************************************
* File Name: Speed_PWM_PM.c
* Version 2.20
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/
#include "cytypes.h"
#include "Speed_PWM.h"

static Speed_PWM_backupStruct Speed_PWM_backup;


/*******************************************************************************
* Function Name: Speed_PWM_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Speed_PWM_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void Speed_PWM_SaveConfig(void) 
{
    
    #if(!Speed_PWM_UsingFixedFunction)
        #if (CY_PSOC5A)
            Speed_PWM_backup.PWMUdb = Speed_PWM_ReadCounter();
            Speed_PWM_backup.PWMPeriod = Speed_PWM_ReadPeriod();
            #if (Speed_PWM_UseStatus)
                Speed_PWM_backup.InterruptMaskValue = Speed_PWM_STATUS_MASK;
            #endif /* (Speed_PWM_UseStatus) */
            
            #if(Speed_PWM_UseOneCompareMode)
                Speed_PWM_backup.PWMCompareValue = Speed_PWM_ReadCompare();
            #else
                Speed_PWM_backup.PWMCompareValue1 = Speed_PWM_ReadCompare1();
                Speed_PWM_backup.PWMCompareValue2 = Speed_PWM_ReadCompare2();
            #endif /* (Speed_PWM_UseOneCompareMode) */
            
           #if(Speed_PWM_DeadBandUsed)
                Speed_PWM_backup.PWMdeadBandValue = Speed_PWM_ReadDeadTime();
            #endif /* (Speed_PWM_DeadBandUsed) */
          
            #if ( Speed_PWM_KillModeMinTime)
                Speed_PWM_backup.PWMKillCounterPeriod = Speed_PWM_ReadKillTime();
            #endif /* ( Speed_PWM_KillModeMinTime) */
        #endif /* (CY_PSOC5A) */
        
        #if (CY_PSOC3 || CY_PSOC5LP)
            #if(!Speed_PWM_PWMModeIsCenterAligned)
                Speed_PWM_backup.PWMPeriod = Speed_PWM_ReadPeriod();
            #endif /* (!Speed_PWM_PWMModeIsCenterAligned) */
            Speed_PWM_backup.PWMUdb = Speed_PWM_ReadCounter();
            #if (Speed_PWM_UseStatus)
                Speed_PWM_backup.InterruptMaskValue = Speed_PWM_STATUS_MASK;
            #endif /* (Speed_PWM_UseStatus) */
            
            #if(Speed_PWM_DeadBandMode == Speed_PWM__B_PWM__DBM_256_CLOCKS || \
                Speed_PWM_DeadBandMode == Speed_PWM__B_PWM__DBM_2_4_CLOCKS)
                Speed_PWM_backup.PWMdeadBandValue = Speed_PWM_ReadDeadTime();
            #endif /*  deadband count is either 2-4 clocks or 256 clocks */
            
            #if(Speed_PWM_KillModeMinTime)
                 Speed_PWM_backup.PWMKillCounterPeriod = Speed_PWM_ReadKillTime();
            #endif /* (Speed_PWM_KillModeMinTime) */
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
        
        #if(Speed_PWM_UseControl)
            Speed_PWM_backup.PWMControlRegister = Speed_PWM_ReadControlRegister();
        #endif /* (Speed_PWM_UseControl) */
    #endif  /* (!Speed_PWM_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Speed_PWM_RestoreConfig
********************************************************************************
* 
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Speed_PWM_backup:  Variables of this global structure are used to  
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Speed_PWM_RestoreConfig(void) 
{
        #if(!Speed_PWM_UsingFixedFunction)
            #if (CY_PSOC5A)
                /* Interrupt State Backup for Critical Region*/
                uint8 Speed_PWM_interruptState;
                /* Enter Critical Region*/
                Speed_PWM_interruptState = CyEnterCriticalSection();
                #if (Speed_PWM_UseStatus)
                    /* Use the interrupt output of the status register for IRQ output */
                    Speed_PWM_STATUS_AUX_CTRL |= Speed_PWM_STATUS_ACTL_INT_EN_MASK;
                    
                    Speed_PWM_STATUS_MASK = Speed_PWM_backup.InterruptMaskValue;
                #endif /* (Speed_PWM_UseStatus) */
                
                #if (Speed_PWM_Resolution == 8)
                    /* Set FIFO 0 to 1 byte register for period*/
                    Speed_PWM_AUX_CONTROLDP0 |= (Speed_PWM_AUX_CTRL_FIFO0_CLR);
                #else /* (Speed_PWM_Resolution == 16)*/
                    /* Set FIFO 0 to 1 byte register for period */
                    Speed_PWM_AUX_CONTROLDP0 |= (Speed_PWM_AUX_CTRL_FIFO0_CLR);
                    Speed_PWM_AUX_CONTROLDP1 |= (Speed_PWM_AUX_CTRL_FIFO0_CLR);
                #endif /* (Speed_PWM_Resolution == 8) */
                /* Exit Critical Region*/
                CyExitCriticalSection(Speed_PWM_interruptState);
                
                Speed_PWM_WriteCounter(Speed_PWM_backup.PWMUdb);
                Speed_PWM_WritePeriod(Speed_PWM_backup.PWMPeriod);
                
                #if(Speed_PWM_UseOneCompareMode)
                    Speed_PWM_WriteCompare(Speed_PWM_backup.PWMCompareValue);
                #else
                    Speed_PWM_WriteCompare1(Speed_PWM_backup.PWMCompareValue1);
                    Speed_PWM_WriteCompare2(Speed_PWM_backup.PWMCompareValue2);
                #endif /* (Speed_PWM_UseOneCompareMode) */
                
               #if(Speed_PWM_DeadBandMode == Speed_PWM__B_PWM__DBM_256_CLOCKS || \
                   Speed_PWM_DeadBandMode == Speed_PWM__B_PWM__DBM_2_4_CLOCKS)
                    Speed_PWM_WriteDeadTime(Speed_PWM_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
            
                #if ( Speed_PWM_KillModeMinTime)
                    Speed_PWM_WriteKillTime(Speed_PWM_backup.PWMKillCounterPeriod);
                #endif /* ( Speed_PWM_KillModeMinTime) */
            #endif /* (CY_PSOC5A) */
            
            #if (CY_PSOC3 || CY_PSOC5LP)
                #if(!Speed_PWM_PWMModeIsCenterAligned)
                    Speed_PWM_WritePeriod(Speed_PWM_backup.PWMPeriod);
                #endif /* (!Speed_PWM_PWMModeIsCenterAligned) */
                Speed_PWM_WriteCounter(Speed_PWM_backup.PWMUdb);
                #if (Speed_PWM_UseStatus)
                    Speed_PWM_STATUS_MASK = Speed_PWM_backup.InterruptMaskValue;
                #endif /* (Speed_PWM_UseStatus) */
                
                #if(Speed_PWM_DeadBandMode == Speed_PWM__B_PWM__DBM_256_CLOCKS || \
                    Speed_PWM_DeadBandMode == Speed_PWM__B_PWM__DBM_2_4_CLOCKS)
                    Speed_PWM_WriteDeadTime(Speed_PWM_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
                
                #if(Speed_PWM_KillModeMinTime)
                    Speed_PWM_WriteKillTime(Speed_PWM_backup.PWMKillCounterPeriod);
                #endif /* (Speed_PWM_KillModeMinTime) */
            #endif /* (CY_PSOC3 || CY_PSOC5LP) */
            
            #if(Speed_PWM_UseControl)
                Speed_PWM_WriteControlRegister(Speed_PWM_backup.PWMControlRegister); 
            #endif /* (Speed_PWM_UseControl) */
        #endif  /* (!Speed_PWM_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: Speed_PWM_Sleep
********************************************************************************
* 
* Summary:
*  Disables block's operation and saves the user configuration. Should be called 
*  just prior to entering sleep.
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Speed_PWM_backup.PWMEnableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void Speed_PWM_Sleep(void) 
{
    #if(Speed_PWM_UseControl)
        if(Speed_PWM_CTRL_ENABLE == (Speed_PWM_CONTROL & Speed_PWM_CTRL_ENABLE))
        {
            /*Component is enabled */
            Speed_PWM_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            Speed_PWM_backup.PWMEnableState = 0u;
        }
    #endif /* (Speed_PWM_UseControl) */
    /* Stop component */
    Speed_PWM_Stop();
    
    /* Save registers configuration */
    Speed_PWM_SaveConfig();
}


/*******************************************************************************
* Function Name: Speed_PWM_Wakeup
********************************************************************************
* 
* Summary:
*  Restores and enables the user configuration. Should be called just after 
*  awaking from sleep.
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Speed_PWM_backup.pwmEnable:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Speed_PWM_Wakeup(void) 
{
     /* Restore registers values */
    Speed_PWM_RestoreConfig();
    
    if(Speed_PWM_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        Speed_PWM_Enable();
    } /* Do nothing if component's block was disabled before */
    
}


/* [] END OF FILE */
