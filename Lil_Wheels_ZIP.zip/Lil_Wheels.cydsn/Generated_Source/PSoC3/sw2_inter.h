/*******************************************************************************
* File Name: sw2_inter.h
* Version 1.60
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/
#if !defined(__sw2_inter_INTC_H__)
#define __sw2_inter_INTC_H__


#include <cytypes.h>
#include <cyfitter.h>

#if(CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3)     
    #if(CYDEV_CHIP_REVISION_USED <= CYDEV_CHIP_REVISION_3A_ES2)      
        #include <intrins.h>
        #define sw2_inter_ISR_PATCH() _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    #endif
#endif


/* Interrupt Controller API. */
void sw2_inter_Start(void);
void sw2_inter_StartEx(cyisraddress address);
void sw2_inter_Stop(void) ;

CY_ISR_PROTO(sw2_inter_Interrupt);

void sw2_inter_SetVector(cyisraddress address) ;
cyisraddress sw2_inter_GetVector(void) ;

void sw2_inter_SetPriority(uint8 priority) ;
uint8 sw2_inter_GetPriority(void) ;

void sw2_inter_Enable(void) ;
uint8 sw2_inter_GetState(void) ;
void sw2_inter_Disable(void) ;

void sw2_inter_SetPending(void) ;
void sw2_inter_ClearPending(void) ;


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the sw2_inter ISR. */
#define sw2_inter_INTC_VECTOR            ((reg16 *) sw2_inter__INTC_VECT)

/* Address of the sw2_inter ISR priority. */
#define sw2_inter_INTC_PRIOR             ((reg8 *) sw2_inter__INTC_PRIOR_REG)

/* Priority of the sw2_inter interrupt. */
#define sw2_inter_INTC_PRIOR_NUMBER      sw2_inter__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable sw2_inter interrupt. */
#define sw2_inter_INTC_SET_EN            ((reg8 *) sw2_inter__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the sw2_inter interrupt. */
#define sw2_inter_INTC_CLR_EN            ((reg8 *) sw2_inter__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the sw2_inter interrupt state to pending. */
#define sw2_inter_INTC_SET_PD            ((reg8 *) sw2_inter__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the sw2_inter interrupt. */
#define sw2_inter_INTC_CLR_PD            ((reg8 *) sw2_inter__INTC_CLR_PD_REG)



/* __sw2_inter_INTC_H__ */
#endif
