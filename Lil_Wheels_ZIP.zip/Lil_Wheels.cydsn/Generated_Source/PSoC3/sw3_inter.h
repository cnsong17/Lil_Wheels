/*******************************************************************************
* File Name: sw3_inter.h
* Version 1.60
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/
#if !defined(__sw3_inter_INTC_H__)
#define __sw3_inter_INTC_H__


#include <cytypes.h>
#include <cyfitter.h>

#if(CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3)     
    #if(CYDEV_CHIP_REVISION_USED <= CYDEV_CHIP_REVISION_3A_ES2)      
        #include <intrins.h>
        #define sw3_inter_ISR_PATCH() _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    #endif
#endif


/* Interrupt Controller API. */
void sw3_inter_Start(void);
void sw3_inter_StartEx(cyisraddress address);
void sw3_inter_Stop(void) ;

CY_ISR_PROTO(sw3_inter_Interrupt);

void sw3_inter_SetVector(cyisraddress address) ;
cyisraddress sw3_inter_GetVector(void) ;

void sw3_inter_SetPriority(uint8 priority) ;
uint8 sw3_inter_GetPriority(void) ;

void sw3_inter_Enable(void) ;
uint8 sw3_inter_GetState(void) ;
void sw3_inter_Disable(void) ;

void sw3_inter_SetPending(void) ;
void sw3_inter_ClearPending(void) ;


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the sw3_inter ISR. */
#define sw3_inter_INTC_VECTOR            ((reg16 *) sw3_inter__INTC_VECT)

/* Address of the sw3_inter ISR priority. */
#define sw3_inter_INTC_PRIOR             ((reg8 *) sw3_inter__INTC_PRIOR_REG)

/* Priority of the sw3_inter interrupt. */
#define sw3_inter_INTC_PRIOR_NUMBER      sw3_inter__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable sw3_inter interrupt. */
#define sw3_inter_INTC_SET_EN            ((reg8 *) sw3_inter__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the sw3_inter interrupt. */
#define sw3_inter_INTC_CLR_EN            ((reg8 *) sw3_inter__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the sw3_inter interrupt state to pending. */
#define sw3_inter_INTC_SET_PD            ((reg8 *) sw3_inter__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the sw3_inter interrupt. */
#define sw3_inter_INTC_CLR_PD            ((reg8 *) sw3_inter__INTC_CLR_PD_REG)



/* __sw3_inter_INTC_H__ */
#endif
