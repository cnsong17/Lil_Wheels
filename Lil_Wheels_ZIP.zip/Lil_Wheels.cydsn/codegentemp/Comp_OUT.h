/*******************************************************************************
* File Name: Comp_OUT.h  
* Version 1.70
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_PINS_Comp_OUT_H) /* Pins Comp_OUT_H */
#define CY_PINS_Comp_OUT_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Comp_OUT_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Comp_OUT_Write(uint8 value) ;
void    Comp_OUT_SetDriveMode(uint8 mode) ;
uint8   Comp_OUT_ReadDataReg(void) ;
uint8   Comp_OUT_Read(void) ;
uint8   Comp_OUT_ClearInterrupt(void) ;

/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Comp_OUT_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Comp_OUT_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Comp_OUT_DM_RES_UP          PIN_DM_RES_UP
#define Comp_OUT_DM_RES_DWN         PIN_DM_RES_DWN
#define Comp_OUT_DM_OD_LO           PIN_DM_OD_LO
#define Comp_OUT_DM_OD_HI           PIN_DM_OD_HI
#define Comp_OUT_DM_STRONG          PIN_DM_STRONG
#define Comp_OUT_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Comp_OUT_MASK               Comp_OUT__MASK
#define Comp_OUT_SHIFT              Comp_OUT__SHIFT
#define Comp_OUT_WIDTH              1u

/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Comp_OUT_PS                     (* (reg8 *) Comp_OUT__PS)
/* Data Register */
#define Comp_OUT_DR                     (* (reg8 *) Comp_OUT__DR)
/* Port Number */
#define Comp_OUT_PRT_NUM                (* (reg8 *) Comp_OUT__PRT) 
/* Connect to Analog Globals */                                                  
#define Comp_OUT_AG                     (* (reg8 *) Comp_OUT__AG)                       
/* Analog MUX bux enable */
#define Comp_OUT_AMUX                   (* (reg8 *) Comp_OUT__AMUX) 
/* Bidirectional Enable */                                                        
#define Comp_OUT_BIE                    (* (reg8 *) Comp_OUT__BIE)
/* Bit-mask for Aliased Register Access */
#define Comp_OUT_BIT_MASK               (* (reg8 *) Comp_OUT__BIT_MASK)
/* Bypass Enable */
#define Comp_OUT_BYP                    (* (reg8 *) Comp_OUT__BYP)
/* Port wide control signals */                                                   
#define Comp_OUT_CTL                    (* (reg8 *) Comp_OUT__CTL)
/* Drive Modes */
#define Comp_OUT_DM0                    (* (reg8 *) Comp_OUT__DM0) 
#define Comp_OUT_DM1                    (* (reg8 *) Comp_OUT__DM1)
#define Comp_OUT_DM2                    (* (reg8 *) Comp_OUT__DM2) 
/* Input Buffer Disable Override */
#define Comp_OUT_INP_DIS                (* (reg8 *) Comp_OUT__INP_DIS)
/* LCD Common or Segment Drive */
#define Comp_OUT_LCD_COM_SEG            (* (reg8 *) Comp_OUT__LCD_COM_SEG)
/* Enable Segment LCD */
#define Comp_OUT_LCD_EN                 (* (reg8 *) Comp_OUT__LCD_EN)
/* Slew Rate Control */
#define Comp_OUT_SLW                    (* (reg8 *) Comp_OUT__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Comp_OUT_PRTDSI__CAPS_SEL       (* (reg8 *) Comp_OUT__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Comp_OUT_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Comp_OUT__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Comp_OUT_PRTDSI__OE_SEL0        (* (reg8 *) Comp_OUT__PRTDSI__OE_SEL0) 
#define Comp_OUT_PRTDSI__OE_SEL1        (* (reg8 *) Comp_OUT__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Comp_OUT_PRTDSI__OUT_SEL0       (* (reg8 *) Comp_OUT__PRTDSI__OUT_SEL0) 
#define Comp_OUT_PRTDSI__OUT_SEL1       (* (reg8 *) Comp_OUT__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Comp_OUT_PRTDSI__SYNC_OUT       (* (reg8 *) Comp_OUT__PRTDSI__SYNC_OUT) 


#if defined(Comp_OUT__INTSTAT)  /* Interrupt Registers */

    #define Comp_OUT_INTSTAT                (* (reg8 *) Comp_OUT__INTSTAT)
    #define Comp_OUT_SNAP                   (* (reg8 *) Comp_OUT__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins Comp_OUT_H */


/* [] END OF FILE */
