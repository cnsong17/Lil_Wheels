/*******************************************************************************
* File Name: Steering_PWM.c  
* Version 2.20
*
* Description:
*  The PWM User Module consist of an 8 or 16-bit counter with two 8 or 16-bit
*  comparitors. Each instance of this user module is capable of generating
*  two PWM outputs with the same period. The pulse width is selectable between
*  1 and 255/65535. The period is selectable between 2 and 255/65536 clocks. 
*  The compare value output may be configured to be active when the present 
*  counter is less than or less than/equal to the compare value.
*  A terminal count output is also provided. It generates a pulse one clock
*  width wide when the counter is equal to zero.
*
* Note:
*
*******************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/

#include "cytypes.h"
#include "Steering_PWM.h"

uint8 Steering_PWM_initVar = 0u;


/*******************************************************************************
* Function Name: Steering_PWM_Start
********************************************************************************
*
* Summary:
*  The start function initializes the pwm with the default values, the 
*  enables the counter to begin counting.  It does not enable interrupts,
*  the EnableInt command should be called if interrupt generation is required.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Global variables:
*  Steering_PWM_initVar: Is modified when this function is called for the 
*   first time. Is used to ensure that initialization happens only once.
*
*******************************************************************************/
void Steering_PWM_Start(void) 
{
    /* If not Initialized then initialize all required hardware and software */
    if(Steering_PWM_initVar == 0u)
    {
        Steering_PWM_Init();
        Steering_PWM_initVar = 1u;
    }
    Steering_PWM_Enable();

}


/*******************************************************************************
* Function Name: Steering_PWM_Init
********************************************************************************
*
* Summary:
*  Initialize component's parameters to the parameters set by user in the 
*  customizer of the component placed onto schematic. Usually called in 
*  Steering_PWM_Start().
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void Steering_PWM_Init(void) 
{
    #if (Steering_PWM_UsingFixedFunction || Steering_PWM_UseControl)
        uint8 ctrl;
    #endif /* (Steering_PWM_UsingFixedFunction || Steering_PWM_UseControl) */
    
    #if(!Steering_PWM_UsingFixedFunction) 
        #if(Steering_PWM_UseStatus)
            /* Interrupt State Backup for Critical Region*/
            uint8 Steering_PWM_interruptState;
        #endif /* (Steering_PWM_UseStatus) */
    #endif /* (!Steering_PWM_UsingFixedFunction) */
    
    #if (Steering_PWM_UsingFixedFunction)
        /* You are allowed to write the compare value (FF only) */
        Steering_PWM_CONTROL |= Steering_PWM_CFG0_MODE;
        #if (Steering_PWM_DeadBand2_4)
            Steering_PWM_CONTROL |= Steering_PWM_CFG0_DB;
        #endif /* (Steering_PWM_DeadBand2_4) */
                
        /* Set the default Compare Mode */
        #if(CY_PSOC5A)
                ctrl = Steering_PWM_CONTROL2 & ~Steering_PWM_CTRL_CMPMODE1_MASK;
                Steering_PWM_CONTROL2 = ctrl | Steering_PWM_DEFAULT_COMPARE1_MODE;
        #endif /* (CY_PSOC5A) */
        #if(CY_PSOC3 || CY_PSOC5LP)
                ctrl = Steering_PWM_CONTROL3 & ~Steering_PWM_CTRL_CMPMODE1_MASK;
                Steering_PWM_CONTROL3 = ctrl | Steering_PWM_DEFAULT_COMPARE1_MODE;
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
        
         /* Clear and Set SYNCTC and SYNCCMP bits of RT1 register */
        Steering_PWM_RT1 &= ~Steering_PWM_RT1_MASK;
        Steering_PWM_RT1 |= Steering_PWM_SYNC;     
                
        /*Enable DSI Sync all all inputs of the PWM*/
        Steering_PWM_RT1 &= ~(Steering_PWM_SYNCDSI_MASK);
        Steering_PWM_RT1 |= Steering_PWM_SYNCDSI_EN;
       
    #elif (Steering_PWM_UseControl)
        /* Set the default compare mode defined in the parameter */
        ctrl = Steering_PWM_CONTROL & ~Steering_PWM_CTRL_CMPMODE2_MASK & ~Steering_PWM_CTRL_CMPMODE1_MASK;
        Steering_PWM_CONTROL = ctrl | Steering_PWM_DEFAULT_COMPARE2_MODE | 
                                   Steering_PWM_DEFAULT_COMPARE1_MODE;
    #endif /* (Steering_PWM_UsingFixedFunction) */
        
    #if (!Steering_PWM_UsingFixedFunction)
        #if (Steering_PWM_Resolution == 8)
            /* Set FIFO 0 to 1 byte register for period*/
            Steering_PWM_AUX_CONTROLDP0 |= (Steering_PWM_AUX_CTRL_FIFO0_CLR);
        #else /* (Steering_PWM_Resolution == 16)*/
            /* Set FIFO 0 to 1 byte register for period */
            Steering_PWM_AUX_CONTROLDP0 |= (Steering_PWM_AUX_CTRL_FIFO0_CLR);
            Steering_PWM_AUX_CONTROLDP1 |= (Steering_PWM_AUX_CTRL_FIFO0_CLR);
        #endif /* (Steering_PWM_Resolution == 8) */

        Steering_PWM_WriteCounter(Steering_PWM_INIT_PERIOD_VALUE);
    #endif /* (!Steering_PWM_UsingFixedFunction) */
        
    Steering_PWM_WritePeriod(Steering_PWM_INIT_PERIOD_VALUE);

        #if (Steering_PWM_UseOneCompareMode)
            Steering_PWM_WriteCompare(Steering_PWM_INIT_COMPARE_VALUE1);
        #else
            Steering_PWM_WriteCompare1(Steering_PWM_INIT_COMPARE_VALUE1);
            Steering_PWM_WriteCompare2(Steering_PWM_INIT_COMPARE_VALUE2);
        #endif /* (Steering_PWM_UseOneCompareMode) */
        
        #if (Steering_PWM_KillModeMinTime)
            Steering_PWM_WriteKillTime(Steering_PWM_MinimumKillTime);
        #endif /* (Steering_PWM_KillModeMinTime) */
        
        #if (Steering_PWM_DeadBandUsed)
            Steering_PWM_WriteDeadTime(Steering_PWM_INIT_DEAD_TIME);
        #endif /* (Steering_PWM_DeadBandUsed) */

    #if (Steering_PWM_UseStatus || Steering_PWM_UsingFixedFunction)
        Steering_PWM_SetInterruptMode(Steering_PWM_INIT_INTERRUPTS_MODE);
    #endif /* (Steering_PWM_UseStatus || Steering_PWM_UsingFixedFunction) */
        
    #if (Steering_PWM_UsingFixedFunction)
        /* Globally Enable the Fixed Function Block chosen */
        Steering_PWM_GLOBAL_ENABLE |= Steering_PWM_BLOCK_EN_MASK;
        /* Set the Interrupt source to come from the status register */
        Steering_PWM_CONTROL2 |= Steering_PWM_CTRL2_IRQ_SEL;
    #else
        #if(Steering_PWM_UseStatus)
            
            /* CyEnterCriticalRegion and CyExitCriticalRegion are used to mark following region critical*/
            /* Enter Critical Region*/
            Steering_PWM_interruptState = CyEnterCriticalSection();
            /* Use the interrupt output of the status register for IRQ output */
            Steering_PWM_STATUS_AUX_CTRL |= Steering_PWM_STATUS_ACTL_INT_EN_MASK;
            
             /* Exit Critical Region*/
            CyExitCriticalSection(Steering_PWM_interruptState);
            
            /* Clear the FIFO to enable the Steering_PWM_STATUS_FIFOFULL
                   bit to be set on FIFO full. */
            Steering_PWM_ClearFIFO();
        #endif /* (Steering_PWM_UseStatus) */
    #endif /* (Steering_PWM_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Steering_PWM_Enable
********************************************************************************
*
* Summary: 
*  Enables the PWM block operation
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Side Effects: 
*  This works only if software enable mode is chosen
*
*******************************************************************************/
void Steering_PWM_Enable(void) 
{
    /* Globally Enable the Fixed Function Block chosen */
    #if (Steering_PWM_UsingFixedFunction)
        Steering_PWM_GLOBAL_ENABLE |= Steering_PWM_BLOCK_EN_MASK;
        Steering_PWM_GLOBAL_STBY_ENABLE |= Steering_PWM_BLOCK_STBY_EN_MASK;
    #endif /* (Steering_PWM_UsingFixedFunction) */
    
    /* Enable the PWM from the control register  */
    #if (Steering_PWM_UseControl || Steering_PWM_UsingFixedFunction)
        Steering_PWM_CONTROL |= Steering_PWM_CTRL_ENABLE;
    #endif /* (Steering_PWM_UseControl || Steering_PWM_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Steering_PWM_Stop
********************************************************************************
*
* Summary:
*  The stop function halts the PWM, but does not change any modes or disable
*  interrupts.
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
* Side Effects:
*  If the Enable mode is set to Hardware only then this function
*  has no effect on the operation of the PWM
*
*******************************************************************************/
void Steering_PWM_Stop(void) 
{
    #if (Steering_PWM_UseControl || Steering_PWM_UsingFixedFunction)
        Steering_PWM_CONTROL &= ~Steering_PWM_CTRL_ENABLE;
    #endif /* (Steering_PWM_UseControl || Steering_PWM_UsingFixedFunction) */
    
    /* Globally disable the Fixed Function Block chosen */
    #if (Steering_PWM_UsingFixedFunction)
        Steering_PWM_GLOBAL_ENABLE &= ~Steering_PWM_BLOCK_EN_MASK;
        Steering_PWM_GLOBAL_STBY_ENABLE &= ~Steering_PWM_BLOCK_STBY_EN_MASK;
    #endif /* (Steering_PWM_UsingFixedFunction) */
}


#if (Steering_PWM_UseOneCompareMode)
#if (Steering_PWM_CompareMode1SW)


/*******************************************************************************
* Function Name: Steering_PWM_SetCompareMode
********************************************************************************
* 
* Summary:
*  This function writes the Compare Mode for the pwm output when in Dither mode,
*  Center Align Mode or One Output Mode.
*
* Parameters:
*  comparemode:  The new compare mode for the PWM output. Use the compare types
*                defined in the H file as input arguments.
*
* Return:
*  void
*
*******************************************************************************/
void Steering_PWM_SetCompareMode(uint8 comparemode) 
{
    #if(Steering_PWM_UsingFixedFunction)
        #if(CY_PSOC5A)
            uint8 comparemodemasked = (comparemode << Steering_PWM_CTRL_CMPMODE1_SHIFT);
            Steering_PWM_CONTROL2 &= ~Steering_PWM_CTRL_CMPMODE1_MASK; /*Clear Existing Data */
            Steering_PWM_CONTROL2 |= comparemodemasked;  
        #endif /* (CY_PSOC5A) */
                
        #if(CY_PSOC3 || CY_PSOC5LP)
            uint8 comparemodemasked = (comparemode << Steering_PWM_CTRL_CMPMODE1_SHIFT);
            Steering_PWM_CONTROL3 &= ~Steering_PWM_CTRL_CMPMODE1_MASK; /*Clear Existing Data */
            Steering_PWM_CONTROL3 |= comparemodemasked;     
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
                
    #elif (Steering_PWM_UseControl)
        uint8 comparemode1masked = (comparemode << Steering_PWM_CTRL_CMPMODE1_SHIFT) & 
                                    Steering_PWM_CTRL_CMPMODE1_MASK;
        uint8 comparemode2masked = (comparemode << Steering_PWM_CTRL_CMPMODE2_SHIFT) & 
                                   Steering_PWM_CTRL_CMPMODE2_MASK;
        /*Clear existing mode */
        Steering_PWM_CONTROL &= ~(Steering_PWM_CTRL_CMPMODE1_MASK | Steering_PWM_CTRL_CMPMODE2_MASK); 
        Steering_PWM_CONTROL |= (comparemode1masked | comparemode2masked);
        
    #else
        uint8 temp = comparemode;
    #endif /* (Steering_PWM_UsingFixedFunction) */
}
#endif /* Steering_PWM_CompareMode1SW */

#else /* UseOneCompareMode */


#if (Steering_PWM_CompareMode1SW)


/*******************************************************************************
* Function Name: Steering_PWM_SetCompareMode1
********************************************************************************
* 
* Summary:
*  This function writes the Compare Mode for the pwm or pwm1 output
*
* Parameters:  
*  comparemode:  The new compare mode for the PWM output. Use the compare types
*                defined in the H file as input arguments.
*
* Return: 
*  void
*
*******************************************************************************/
void Steering_PWM_SetCompareMode1(uint8 comparemode) 
{
    uint8 comparemodemasked = (comparemode << Steering_PWM_CTRL_CMPMODE1_SHIFT) & 
                               Steering_PWM_CTRL_CMPMODE1_MASK;
    #if(Steering_PWM_UsingFixedFunction)
        #if(CY_PSOC5A)
            Steering_PWM_CONTROL2 &= Steering_PWM_CTRL_CMPMODE1_MASK; /*Clear existing mode */
            Steering_PWM_CONTROL2 |= comparemodemasked; 
        #endif /* (CY_PSOC5A) */
                
        #if(CY_PSOC3 || CY_PSOC5LP)
            Steering_PWM_CONTROL3 &= Steering_PWM_CTRL_CMPMODE1_MASK; /*Clear existing mode */
            Steering_PWM_CONTROL3 |= comparemodemasked; 
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
                
    #elif (Steering_PWM_UseControl)
        Steering_PWM_CONTROL &= Steering_PWM_CTRL_CMPMODE1_MASK; /*Clear existing mode */
        Steering_PWM_CONTROL |= comparemodemasked;
    #endif    /* (Steering_PWM_UsingFixedFunction) */
}
#endif /* Steering_PWM_CompareMode1SW */


#if (Steering_PWM_CompareMode2SW)


/*******************************************************************************
* Function Name: Steering_PWM_SetCompareMode2
********************************************************************************
* 
* Summary:
*  This function writes the Compare Mode for the pwm or pwm2 output
*
* Parameters:  
*  comparemode:  The new compare mode for the PWM output. Use the compare types
*                defined in the H file as input arguments.
*
* Return: 
*  void
*
*******************************************************************************/
void Steering_PWM_SetCompareMode2(uint8 comparemode) 
{
    #if(Steering_PWM_UsingFixedFunction)
        /* Do Nothing because there is no second Compare Mode Register in FF block */ 
    #elif (Steering_PWM_UseControl)
        uint8 comparemodemasked = (comparemode << Steering_PWM_CTRL_CMPMODE2_SHIFT) & 
                                             Steering_PWM_CTRL_CMPMODE2_MASK;
        Steering_PWM_CONTROL &= Steering_PWM_CTRL_CMPMODE2_MASK; /*Clear existing mode */
        Steering_PWM_CONTROL |= comparemodemasked;
    #endif /* (Steering_PWM_UsingFixedFunction) */
}
#endif /*Steering_PWM_CompareMode2SW */
#endif /* UseOneCompareMode */


#if (!Steering_PWM_UsingFixedFunction)


/*******************************************************************************
* Function Name: Steering_PWM_WriteCounter
********************************************************************************
* 
* Summary:
*  This function is used to change the counter value.
*
* Parameters:  
*  counter:  This value may be between 1 and (2^Resolution)-1.   
*
* Return: 
*  void
*
*******************************************************************************/
void Steering_PWM_WriteCounter(uint16 counter) \
                                   
{
    CY_SET_REG16(Steering_PWM_COUNTER_LSB_PTR, counter);
}

/*******************************************************************************
* Function Name: Steering_PWM_ReadCounter
********************************************************************************
* 
* Summary:
*  This function returns the current value of the counter.  It doesn't matter
*  if the counter is enabled or running.
*
* Parameters:  
*  void  
*
* Return: 
*  The current value of the counter.
*
*******************************************************************************/
uint16 Steering_PWM_ReadCounter(void) 
{
    /* Force capture by reading Accumulator */
    /* Must first do a software capture to be able to read the counter */
    /* It is up to the user code to make sure there isn't already captured data in the FIFO */
    CY_GET_REG8(Steering_PWM_COUNTERCAP_LSB_PTR);
    
    /* Read the data from the FIFO (or capture register for Fixed Function)*/
    return (CY_GET_REG16(Steering_PWM_CAPTURE_LSB_PTR));
}


#if (Steering_PWM_UseStatus)


/*******************************************************************************
* Function Name: Steering_PWM_ClearFIFO
********************************************************************************
* 
* Summary:
*  This function clears all capture data from the capture FIFO
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void Steering_PWM_ClearFIFO(void) 
{
    while(Steering_PWM_ReadStatusRegister() & Steering_PWM_STATUS_FIFONEMPTY)
        Steering_PWM_ReadCapture();
}
#endif /* Steering_PWM_UseStatus */
#endif /* !Steering_PWM_UsingFixedFunction */


/*******************************************************************************
* Function Name: Steering_PWM_WritePeriod
********************************************************************************
* 
* Summary:
*  This function is used to change the period of the counter.  The new period 
*  will be loaded the next time terminal count is detected.
*
* Parameters:  
*  period:  Period value. May be between 1 and (2^Resolution)-1.  A value of 0 
*           will result in the counter remaining at zero.
*
* Return: 
*  void
*
*******************************************************************************/
void Steering_PWM_WritePeriod(uint16 period) 
{
    #if(Steering_PWM_UsingFixedFunction)
        CY_SET_REG16(Steering_PWM_PERIOD_LSB_PTR, (uint16)period);
    #else
        CY_SET_REG16(Steering_PWM_PERIOD_LSB_PTR, period);
    #endif /* (Steering_PWM_UsingFixedFunction) */
}


#if (Steering_PWM_UseOneCompareMode)


/*******************************************************************************
* Function Name: Steering_PWM_WriteCompare
********************************************************************************
* 
* Summary:
*  This funtion is used to change the compare1 value when the PWM is in Dither
*  mode. The compare output will reflect the new value on the next UDB clock. 
*  The compare output will be driven high when the present counter value is 
*  compared to the compare value based on the compare mode defined in 
*  Dither Mode.
*
* Parameters:  
*  compare:  New compare value.  
*
* Return: 
*  void
*
* Side Effects:
*  This function is only available if the PWM mode parameter is set to
*  Dither Mode, Center Aligned Mode or One Output Mode
*
*******************************************************************************/
void Steering_PWM_WriteCompare(uint16 compare) \
                                   
{
   CY_SET_REG16(Steering_PWM_COMPARE1_LSB_PTR, compare);
   #if (Steering_PWM_PWMMode == Steering_PWM__B_PWM__DITHER)
        CY_SET_REG16(Steering_PWM_COMPARE2_LSB_PTR, compare+1);
   #endif /* (Steering_PWM_PWMMode == Steering_PWM__B_PWM__DITHER) */
}


#else


/*******************************************************************************
* Function Name: Steering_PWM_WriteCompare1
********************************************************************************
* 
* Summary:
*  This funtion is used to change the compare1 value.  The compare output will 
*  reflect the new value on the next UDB clock.  The compare output will be 
*  driven high when the present counter value is less than or less than or 
*  equal to the compare register, depending on the mode.
*
* Parameters:  
*  compare:  New compare value.  
*
* Return: 
*  void
*
*******************************************************************************/
void Steering_PWM_WriteCompare1(uint16 compare) \
                                    
{
    #if(Steering_PWM_UsingFixedFunction)
        CY_SET_REG16(Steering_PWM_COMPARE1_LSB_PTR, (uint16)compare);
    #else
        CY_SET_REG16(Steering_PWM_COMPARE1_LSB_PTR, compare);
    #endif /* (Steering_PWM_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Steering_PWM_WriteCompare2
********************************************************************************
* 
* Summary:
*  This funtion is used to change the compare value, for compare1 output.  
*  The compare output will reflect the new value on the next UDB clock.  
*  The compare output will be driven high when the present counter value is 
*  less than or less than or equal to the compare register, depending on the 
*  mode.
*
* Parameters:  
*  compare:  New compare value.  
*
* Return: 
*  void
*
*******************************************************************************/
void Steering_PWM_WriteCompare2(uint16 compare) \
                                    
{
    #if(Steering_PWM_UsingFixedFunction)
        CY_SET_REG16(Steering_PWM_COMPARE2_LSB_PTR, compare);
    #else
        CY_SET_REG16(Steering_PWM_COMPARE2_LSB_PTR, compare);
    #endif /* (Steering_PWM_UsingFixedFunction) */
}
#endif /* UseOneCompareMode */


#if (Steering_PWM_DeadBandUsed)


/*******************************************************************************
* Function Name: Steering_PWM_WriteDeadTime
********************************************************************************
* 
* Summary:
*  This function writes the dead-band counts to the corresponding register
*
* Parameters:  
*  deadtime:  Number of counts for dead time 
*
* Return: 
*  void
*
*******************************************************************************/
void Steering_PWM_WriteDeadTime(uint8 deadtime) 
{
    /* If using the Dead Band 1-255 mode then just write the register */
    #if(!Steering_PWM_DeadBand2_4)
        CY_SET_REG8(Steering_PWM_DEADBAND_COUNT_PTR, deadtime);
    #else
        /* Otherwise the data has to be masked and offset */        
        /* Clear existing data */
        Steering_PWM_DEADBAND_COUNT &= ~Steering_PWM_DEADBAND_COUNT_MASK; 
            /* Set new dead time */
        Steering_PWM_DEADBAND_COUNT |= (deadtime << Steering_PWM_DEADBAND_COUNT_SHIFT) & 
                                            Steering_PWM_DEADBAND_COUNT_MASK; 
    #endif /* (!Steering_PWM_DeadBand2_4) */
}


/*******************************************************************************
* Function Name: Steering_PWM_ReadDeadTime
********************************************************************************
* 
* Summary:
*  This function reads the dead-band counts from the corresponding register
*
* Parameters:  
*  void
*
* Return: 
*  Dead Band Counts
*
*******************************************************************************/
uint8 Steering_PWM_ReadDeadTime(void) 
{
    /* If using the Dead Band 1-255 mode then just read the register */
    #if(!Steering_PWM_DeadBand2_4)
        return (CY_GET_REG8(Steering_PWM_DEADBAND_COUNT_PTR));
    #else
        /* Otherwise the data has to be masked and offset */
        return ((Steering_PWM_DEADBAND_COUNT & Steering_PWM_DEADBAND_COUNT_MASK) >> 
                 Steering_PWM_DEADBAND_COUNT_SHIFT);
    #endif /* (!Steering_PWM_DeadBand2_4) */
}
#endif /* DeadBandUsed */


/* [] END OF FILE */
