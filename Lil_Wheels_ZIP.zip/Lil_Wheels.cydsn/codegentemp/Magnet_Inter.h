/*******************************************************************************
* File Name: Magnet_Inter.h
* Version 1.60
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2010, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
********************************************************************************/
#if !defined(__Magnet_Inter_INTC_H__)
#define __Magnet_Inter_INTC_H__


#include <cytypes.h>
#include <cyfitter.h>

#if(CYDEV_CHIP_FAMILY_USED == CYDEV_CHIP_FAMILY_PSOC3)     
    #if(CYDEV_CHIP_REVISION_USED <= CYDEV_CHIP_REVISION_3A_ES2)      
        #include <intrins.h>
        #define Magnet_Inter_ISR_PATCH() _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_(); _nop_();
    #endif
#endif


/* Interrupt Controller API. */
void Magnet_Inter_Start(void);
void Magnet_Inter_StartEx(cyisraddress address);
void Magnet_Inter_Stop(void) ;

CY_ISR_PROTO(Magnet_Inter_Interrupt);

void Magnet_Inter_SetVector(cyisraddress address) ;
cyisraddress Magnet_Inter_GetVector(void) ;

void Magnet_Inter_SetPriority(uint8 priority) ;
uint8 Magnet_Inter_GetPriority(void) ;

void Magnet_Inter_Enable(void) ;
uint8 Magnet_Inter_GetState(void) ;
void Magnet_Inter_Disable(void) ;

void Magnet_Inter_SetPending(void) ;
void Magnet_Inter_ClearPending(void) ;


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the Magnet_Inter ISR. */
#define Magnet_Inter_INTC_VECTOR            ((reg16 *) Magnet_Inter__INTC_VECT)

/* Address of the Magnet_Inter ISR priority. */
#define Magnet_Inter_INTC_PRIOR             ((reg8 *) Magnet_Inter__INTC_PRIOR_REG)

/* Priority of the Magnet_Inter interrupt. */
#define Magnet_Inter_INTC_PRIOR_NUMBER      Magnet_Inter__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable Magnet_Inter interrupt. */
#define Magnet_Inter_INTC_SET_EN            ((reg8 *) Magnet_Inter__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the Magnet_Inter interrupt. */
#define Magnet_Inter_INTC_CLR_EN            ((reg8 *) Magnet_Inter__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the Magnet_Inter interrupt state to pending. */
#define Magnet_Inter_INTC_SET_PD            ((reg8 *) Magnet_Inter__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the Magnet_Inter interrupt. */
#define Magnet_Inter_INTC_CLR_PD            ((reg8 *) Magnet_Inter__INTC_CLR_PD_REG)



/* __Magnet_Inter_INTC_H__ */
#endif
