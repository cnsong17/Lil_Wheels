/*******************************************************************************
* File Name: Steering_PWM_PM.c
* Version 2.20
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/
#include "cytypes.h"
#include "Steering_PWM.h"

static Steering_PWM_backupStruct Steering_PWM_backup;


/*******************************************************************************
* Function Name: Steering_PWM_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Steering_PWM_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void Steering_PWM_SaveConfig(void) 
{
    
    #if(!Steering_PWM_UsingFixedFunction)
        #if (CY_PSOC5A)
            Steering_PWM_backup.PWMUdb = Steering_PWM_ReadCounter();
            Steering_PWM_backup.PWMPeriod = Steering_PWM_ReadPeriod();
            #if (Steering_PWM_UseStatus)
                Steering_PWM_backup.InterruptMaskValue = Steering_PWM_STATUS_MASK;
            #endif /* (Steering_PWM_UseStatus) */
            
            #if(Steering_PWM_UseOneCompareMode)
                Steering_PWM_backup.PWMCompareValue = Steering_PWM_ReadCompare();
            #else
                Steering_PWM_backup.PWMCompareValue1 = Steering_PWM_ReadCompare1();
                Steering_PWM_backup.PWMCompareValue2 = Steering_PWM_ReadCompare2();
            #endif /* (Steering_PWM_UseOneCompareMode) */
            
           #if(Steering_PWM_DeadBandUsed)
                Steering_PWM_backup.PWMdeadBandValue = Steering_PWM_ReadDeadTime();
            #endif /* (Steering_PWM_DeadBandUsed) */
          
            #if ( Steering_PWM_KillModeMinTime)
                Steering_PWM_backup.PWMKillCounterPeriod = Steering_PWM_ReadKillTime();
            #endif /* ( Steering_PWM_KillModeMinTime) */
        #endif /* (CY_PSOC5A) */
        
        #if (CY_PSOC3 || CY_PSOC5LP)
            #if(!Steering_PWM_PWMModeIsCenterAligned)
                Steering_PWM_backup.PWMPeriod = Steering_PWM_ReadPeriod();
            #endif /* (!Steering_PWM_PWMModeIsCenterAligned) */
            Steering_PWM_backup.PWMUdb = Steering_PWM_ReadCounter();
            #if (Steering_PWM_UseStatus)
                Steering_PWM_backup.InterruptMaskValue = Steering_PWM_STATUS_MASK;
            #endif /* (Steering_PWM_UseStatus) */
            
            #if(Steering_PWM_DeadBandMode == Steering_PWM__B_PWM__DBM_256_CLOCKS || \
                Steering_PWM_DeadBandMode == Steering_PWM__B_PWM__DBM_2_4_CLOCKS)
                Steering_PWM_backup.PWMdeadBandValue = Steering_PWM_ReadDeadTime();
            #endif /*  deadband count is either 2-4 clocks or 256 clocks */
            
            #if(Steering_PWM_KillModeMinTime)
                 Steering_PWM_backup.PWMKillCounterPeriod = Steering_PWM_ReadKillTime();
            #endif /* (Steering_PWM_KillModeMinTime) */
        #endif /* (CY_PSOC3 || CY_PSOC5LP) */
        
        #if(Steering_PWM_UseControl)
            Steering_PWM_backup.PWMControlRegister = Steering_PWM_ReadControlRegister();
        #endif /* (Steering_PWM_UseControl) */
    #endif  /* (!Steering_PWM_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Steering_PWM_RestoreConfig
********************************************************************************
* 
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Steering_PWM_backup:  Variables of this global structure are used to  
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Steering_PWM_RestoreConfig(void) 
{
        #if(!Steering_PWM_UsingFixedFunction)
            #if (CY_PSOC5A)
                /* Interrupt State Backup for Critical Region*/
                uint8 Steering_PWM_interruptState;
                /* Enter Critical Region*/
                Steering_PWM_interruptState = CyEnterCriticalSection();
                #if (Steering_PWM_UseStatus)
                    /* Use the interrupt output of the status register for IRQ output */
                    Steering_PWM_STATUS_AUX_CTRL |= Steering_PWM_STATUS_ACTL_INT_EN_MASK;
                    
                    Steering_PWM_STATUS_MASK = Steering_PWM_backup.InterruptMaskValue;
                #endif /* (Steering_PWM_UseStatus) */
                
                #if (Steering_PWM_Resolution == 8)
                    /* Set FIFO 0 to 1 byte register for period*/
                    Steering_PWM_AUX_CONTROLDP0 |= (Steering_PWM_AUX_CTRL_FIFO0_CLR);
                #else /* (Steering_PWM_Resolution == 16)*/
                    /* Set FIFO 0 to 1 byte register for period */
                    Steering_PWM_AUX_CONTROLDP0 |= (Steering_PWM_AUX_CTRL_FIFO0_CLR);
                    Steering_PWM_AUX_CONTROLDP1 |= (Steering_PWM_AUX_CTRL_FIFO0_CLR);
                #endif /* (Steering_PWM_Resolution == 8) */
                /* Exit Critical Region*/
                CyExitCriticalSection(Steering_PWM_interruptState);
                
                Steering_PWM_WriteCounter(Steering_PWM_backup.PWMUdb);
                Steering_PWM_WritePeriod(Steering_PWM_backup.PWMPeriod);
                
                #if(Steering_PWM_UseOneCompareMode)
                    Steering_PWM_WriteCompare(Steering_PWM_backup.PWMCompareValue);
                #else
                    Steering_PWM_WriteCompare1(Steering_PWM_backup.PWMCompareValue1);
                    Steering_PWM_WriteCompare2(Steering_PWM_backup.PWMCompareValue2);
                #endif /* (Steering_PWM_UseOneCompareMode) */
                
               #if(Steering_PWM_DeadBandMode == Steering_PWM__B_PWM__DBM_256_CLOCKS || \
                   Steering_PWM_DeadBandMode == Steering_PWM__B_PWM__DBM_2_4_CLOCKS)
                    Steering_PWM_WriteDeadTime(Steering_PWM_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
            
                #if ( Steering_PWM_KillModeMinTime)
                    Steering_PWM_WriteKillTime(Steering_PWM_backup.PWMKillCounterPeriod);
                #endif /* ( Steering_PWM_KillModeMinTime) */
            #endif /* (CY_PSOC5A) */
            
            #if (CY_PSOC3 || CY_PSOC5LP)
                #if(!Steering_PWM_PWMModeIsCenterAligned)
                    Steering_PWM_WritePeriod(Steering_PWM_backup.PWMPeriod);
                #endif /* (!Steering_PWM_PWMModeIsCenterAligned) */
                Steering_PWM_WriteCounter(Steering_PWM_backup.PWMUdb);
                #if (Steering_PWM_UseStatus)
                    Steering_PWM_STATUS_MASK = Steering_PWM_backup.InterruptMaskValue;
                #endif /* (Steering_PWM_UseStatus) */
                
                #if(Steering_PWM_DeadBandMode == Steering_PWM__B_PWM__DBM_256_CLOCKS || \
                    Steering_PWM_DeadBandMode == Steering_PWM__B_PWM__DBM_2_4_CLOCKS)
                    Steering_PWM_WriteDeadTime(Steering_PWM_backup.PWMdeadBandValue);
                #endif /* deadband count is either 2-4 clocks or 256 clocks */
                
                #if(Steering_PWM_KillModeMinTime)
                    Steering_PWM_WriteKillTime(Steering_PWM_backup.PWMKillCounterPeriod);
                #endif /* (Steering_PWM_KillModeMinTime) */
            #endif /* (CY_PSOC3 || CY_PSOC5LP) */
            
            #if(Steering_PWM_UseControl)
                Steering_PWM_WriteControlRegister(Steering_PWM_backup.PWMControlRegister); 
            #endif /* (Steering_PWM_UseControl) */
        #endif  /* (!Steering_PWM_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: Steering_PWM_Sleep
********************************************************************************
* 
* Summary:
*  Disables block's operation and saves the user configuration. Should be called 
*  just prior to entering sleep.
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Steering_PWM_backup.PWMEnableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void Steering_PWM_Sleep(void) 
{
    #if(Steering_PWM_UseControl)
        if(Steering_PWM_CTRL_ENABLE == (Steering_PWM_CONTROL & Steering_PWM_CTRL_ENABLE))
        {
            /*Component is enabled */
            Steering_PWM_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            Steering_PWM_backup.PWMEnableState = 0u;
        }
    #endif /* (Steering_PWM_UseControl) */
    /* Stop component */
    Steering_PWM_Stop();
    
    /* Save registers configuration */
    Steering_PWM_SaveConfig();
}


/*******************************************************************************
* Function Name: Steering_PWM_Wakeup
********************************************************************************
* 
* Summary:
*  Restores and enables the user configuration. Should be called just after 
*  awaking from sleep.
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Steering_PWM_backup.pwmEnable:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Steering_PWM_Wakeup(void) 
{
     /* Restore registers values */
    Steering_PWM_RestoreConfig();
    
    if(Steering_PWM_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        Steering_PWM_Enable();
    } /* Do nothing if component's block was disabled before */
    
}


/* [] END OF FILE */
