/*******************************************************************************
* File Name: Comp_Ref_DAC_1_PM.c  
* Version 1.80
*
* Description:
*  This file provides the power management source code to API for the
*  VDAC8.  
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Comp_Ref_DAC_1.h"

static Comp_Ref_DAC_1_backupStruct Comp_Ref_DAC_1_backup;


/*******************************************************************************
* Function Name: Comp_Ref_DAC_1_SaveConfig
********************************************************************************
* Summary:
*  Save the current user configuration
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void Comp_Ref_DAC_1_SaveConfig(void) 
{
    if (!((Comp_Ref_DAC_1_CR1 & Comp_Ref_DAC_1_SRC_MASK) == Comp_Ref_DAC_1_SRC_UDB))
    {
        Comp_Ref_DAC_1_backup.data_value = Comp_Ref_DAC_1_Data;
    }
}


/*******************************************************************************
* Function Name: Comp_Ref_DAC_1_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void Comp_Ref_DAC_1_RestoreConfig(void) 
{
    if (!((Comp_Ref_DAC_1_CR1 & Comp_Ref_DAC_1_SRC_MASK) == Comp_Ref_DAC_1_SRC_UDB))
    {
        if((Comp_Ref_DAC_1_Strobe & Comp_Ref_DAC_1_STRB_MASK) == Comp_Ref_DAC_1_STRB_EN)
        {
            Comp_Ref_DAC_1_Strobe &= ~Comp_Ref_DAC_1_STRB_MASK;
            Comp_Ref_DAC_1_Data = Comp_Ref_DAC_1_backup.data_value;
            Comp_Ref_DAC_1_Strobe |= Comp_Ref_DAC_1_STRB_EN;
        }
        else
        {
            Comp_Ref_DAC_1_Data = Comp_Ref_DAC_1_backup.data_value;
        }
    }
}


/*******************************************************************************
* Function Name: Comp_Ref_DAC_1_Sleep
********************************************************************************
* Summary:
*  Stop and Save the user configuration
*
* Parameters:  
*  void:  
*
* Return: 
*  void
*
* Global variables:
*  Comp_Ref_DAC_1_backup.enableState:  Is modified depending on the enable 
*  state  of the block before entering sleep mode.
*
*******************************************************************************/
void Comp_Ref_DAC_1_Sleep(void) 
{
    /* Save VDAC8's enable state */    
    if(Comp_Ref_DAC_1_ACT_PWR_EN == (Comp_Ref_DAC_1_PWRMGR & Comp_Ref_DAC_1_ACT_PWR_EN))
    {
        /* VDAC8 is enabled */
        Comp_Ref_DAC_1_backup.enableState = 1u;
    }
    else
    {
        /* VDAC8 is disabled */
        Comp_Ref_DAC_1_backup.enableState = 0u;
    }
    
    Comp_Ref_DAC_1_Stop();
    Comp_Ref_DAC_1_SaveConfig();
}


/*******************************************************************************
* Function Name: Comp_Ref_DAC_1_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Comp_Ref_DAC_1_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Comp_Ref_DAC_1_Wakeup(void) 
{
    Comp_Ref_DAC_1_RestoreConfig();
    
    if(Comp_Ref_DAC_1_backup.enableState == 1u)
    {
        /* Enable VDAC8's operation */
        Comp_Ref_DAC_1_Enable();

        /* Restore the data register */
        Comp_Ref_DAC_1_SetValue(Comp_Ref_DAC_1_Data);
    } /* Do nothing if VDAC8 was disabled before */    
}


/* [] END OF FILE */
