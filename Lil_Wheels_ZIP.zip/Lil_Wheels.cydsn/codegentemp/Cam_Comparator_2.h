/*******************************************************************************
* File Name: Cam_Comparator_2.c
* Version 1.90
*
* Description:
*  This file contains the function prototypes and constants used in
*  the Analog Comparator User Module.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_COMP_Cam_Comparator_2_H) 
#define CY_COMP_Cam_Comparator_2_H

#include "cytypes.h"
#include "CyLib.h"
#include "cyfitter.h" 


#define Cam_Comparator_2_RECALMODE 0u

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component Comp_v1_90 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*       Type defines
***************************************/

/* Sleep Mode API Support */
typedef struct Cam_Comparator_2_backupStruct
{
    uint8 enableState;
   /* uint8 compCRReg; */
}Cam_Comparator_2_backupStruct;

#if (CY_PSOC5A)
    /* Stop API changes for PSoC5A */
    typedef struct _Cam_Comparator_2_lowPowerBackupStruct
    {
        uint8 compCRReg;
    }   Cam_Comparator_2_LOWPOWER_BACKUP_STRUCT;
#endif /* CY_PSOC5A */


/**************************************
*        Function Prototypes 
**************************************/

void    Cam_Comparator_2_Start(void)                  ;
void    Cam_Comparator_2_Stop(void)                   ;
void    Cam_Comparator_2_SetSpeed(uint8 speed)        ;
uint8   Cam_Comparator_2_GetCompare(void)             ;
uint16  Cam_Comparator_2_ZeroCal(void)                ;
void    Cam_Comparator_2_LoadTrim(uint16 trimVal)     ;
void Cam_Comparator_2_Init(void)                      ; 
void Cam_Comparator_2_Enable(void)                    ;
void Cam_Comparator_2_trimAdjust(uint8 nibble)        ;
void Cam_Comparator_2_SaveConfig(void)                ;
void Cam_Comparator_2_RestoreConfig(void)             ;
void Cam_Comparator_2_Sleep(void)                     ;
void Cam_Comparator_2_Wakeup(void)                    ;
/* Below APIs are valid only for PSoC3, PSoC5LP silicons.*/
#if (CY_PSOC3 || CY_PSOC5LP) 
    void Cam_Comparator_2_PwrDwnOverrideEnable(void)  ;
    void Cam_Comparator_2_PwrDwnOverrideDisable(void) ;
#endif /* CY_PSOC3 || CY_PSOC5LP */


/**************************************
*           API Constants        
**************************************/

/* Power constants for SetSpeed() function */
#define Cam_Comparator_2_SLOWSPEED   0x00u
#define Cam_Comparator_2_HIGHSPEED   0x01u
#define Cam_Comparator_2_LOWPOWER    0x02u


/***************************************
*         Trim Locations               
****************************************/

/* High speed trim values */
#define Cam_Comparator_2_HS_TRIM_TR0        (CY_GET_XTND_REG8(Cam_Comparator_2_ctComp__TRIM__TR0_HS))

#if (CY_PSOC3 || CY_PSOC5LP)
    #define Cam_Comparator_2_HS_TRIM_TR1    (CY_GET_XTND_REG8(Cam_Comparator_2_ctComp__TRIM__TR1_HS))
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

/* Low speed trim values */
#define Cam_Comparator_2_LS_TRIM_TR0        (CY_GET_XTND_REG8(Cam_Comparator_2_ctComp__TRIM__TR0 + 1))

#if (CY_PSOC3 || CY_PSOC5LP)
    #define Cam_Comparator_2_LS_TRIM_TR1    (CY_GET_XTND_REG8(Cam_Comparator_2_ctComp__TRIM__TR1 + 1))
#endif /* CY_PSOC3 || CY_PSOC5LP */


/**************************************
*           Parameter Defaults        
**************************************/

#define Cam_Comparator_2_DEFAULT_SPEED       1u 
#define Cam_Comparator_2_DEFAULT_HYSTERESIS  1u
#define Cam_Comparator_2_DEFAULT_POLARITY    0u
#define Cam_Comparator_2_DEFAULT_BYPASS_SYNC 0u
#define Cam_Comparator_2_DEFAULT_PWRDWN_OVRD 0u


/**************************************
*             Registers        
**************************************/

#define Cam_Comparator_2_CR      (* (reg8 *) Cam_Comparator_2_ctComp__CR )   /* Config register   */
#define Cam_Comparator_2_CR_PTR  (  (reg8 *) Cam_Comparator_2_ctComp__CR )
#define Cam_Comparator_2_CLK     (* (reg8 *) Cam_Comparator_2_ctComp__CLK )  /* Comp clock control register */
#define Cam_Comparator_2_CLK_PTR (  (reg8 *) Cam_Comparator_2_ctComp__CLK )
#define Cam_Comparator_2_SW0     (* (reg8 *) Cam_Comparator_2_ctComp__SW0 )  /* Routing registers */
#define Cam_Comparator_2_SW0_PTR (  (reg8 *) Cam_Comparator_2_ctComp__SW0 )
#define Cam_Comparator_2_SW2     (* (reg8 *) Cam_Comparator_2_ctComp__SW2 )
#define Cam_Comparator_2_SW2_PTR (  (reg8 *) Cam_Comparator_2_ctComp__SW2 )
#define Cam_Comparator_2_SW3     (* (reg8 *) Cam_Comparator_2_ctComp__SW3 )
#define Cam_Comparator_2_SW3_PTR (  (reg8 *) Cam_Comparator_2_ctComp__SW3 )
#define Cam_Comparator_2_SW4     (* (reg8 *) Cam_Comparator_2_ctComp__SW4 )
#define Cam_Comparator_2_SW4_PTR (  (reg8 *) Cam_Comparator_2_ctComp__SW4 )
#define Cam_Comparator_2_SW6     (* (reg8 *) Cam_Comparator_2_ctComp__SW6 )
#define Cam_Comparator_2_SW6_PTR (  (reg8 *) Cam_Comparator_2_ctComp__SW6 )

/* Trim registers */
/* PSoC5A */
#if (CY_PSOC5A)
    #define Cam_Comparator_2_TR      (* (reg8 *) Cam_Comparator_2_ctComp__TR )   /* Trim registers */
    #define Cam_Comparator_2_TR_PTR  (  (reg8 *) Cam_Comparator_2_ctComp__TR )
#endif /* CY_PSOC5A */

/* PSoC3, PSoC5LP or later */
#if (CY_PSOC3 || CY_PSOC5LP) 
    #define Cam_Comparator_2_TR0         (* (reg8 *) Cam_Comparator_2_ctComp__TR0 ) /* Trim register for P-type load */
    #define Cam_Comparator_2_TR0_PTR     (  (reg8 *) Cam_Comparator_2_ctComp__TR0 ) 
    #define Cam_Comparator_2_TR1         (* (reg8 *) Cam_Comparator_2_ctComp__TR1 ) /* Trim register for N-type load */
    #define Cam_Comparator_2_TR1_PTR     (  (reg8 *) Cam_Comparator_2_ctComp__TR1 ) 
#endif /* CY_PSOC3 || CY_PSOC5LP */

#define Cam_Comparator_2_WRK             (* (reg8 *) Cam_Comparator_2_ctComp__WRK )  /* Working register - output */
#define Cam_Comparator_2_WRK_PTR         (  (reg8 *) Cam_Comparator_2_ctComp__WRK )
#define Cam_Comparator_2_PWRMGR          (* (reg8 *) Cam_Comparator_2_ctComp__PM_ACT_CFG )  /* Active Power manager */
#define Cam_Comparator_2_PWRMGR_PTR      ( (reg8 *) Cam_Comparator_2_ctComp__PM_ACT_CFG )
#define Cam_Comparator_2_STBY_PWRMGR     (* (reg8 *) Cam_Comparator_2_ctComp__PM_STBY_CFG )  /* Standby Power manager */
#define Cam_Comparator_2_STBY_PWRMGR_PTR ( (reg8 *) Cam_Comparator_2_ctComp__PM_STBY_CFG )


/**************************************
*       Register Constants        
**************************************/

/* CR (Comp Control Register)             */
#define Cam_Comparator_2_CFG_MODE_MASK  0x78u
#define Cam_Comparator_2_FILTER_ON      0x40u
#define Cam_Comparator_2_HYST_OFF       0x20u
#define Cam_Comparator_2_CAL_ON         0x10u
#define Cam_Comparator_2_MX_AO          0x08u
#define Cam_Comparator_2_PWRDWN_OVRD    0x04u

#define Cam_Comparator_2_PWR_MODE_SHIFT 0x00u
#define Cam_Comparator_2_PWR_MODE_MASK  (0x03u << Cam_Comparator_2_PWR_MODE_SHIFT)
#define Cam_Comparator_2_PWR_MODE_SLOW  (0x00u << Cam_Comparator_2_PWR_MODE_SHIFT)
#define Cam_Comparator_2_PWR_MODE_FAST  (0x01u << Cam_Comparator_2_PWR_MODE_SHIFT)
#define Cam_Comparator_2_PWR_MODE_ULOW  (0x02u << Cam_Comparator_2_PWR_MODE_SHIFT)

/* CLK (Comp Clock Control Register)      */
#define Cam_Comparator_2_BYPASS_SYNC    0x10u
#define Cam_Comparator_2_SYNC_CLK_EN    0x08u
#define Cam_Comparator_2_SYNCCLK_MASK   (Cam_Comparator_2_BYPASS_SYNC | Cam_Comparator_2_SYNC_CLK_EN)

/* SW3 Routing Register definitions */
#define Cam_Comparator_2_CMP_SW3_INPCTL_MASK    0x09u   /* SW3 bits for inP routing control */

/* TR (Comp Trim Register)     */
#define Cam_Comparator_2_DEFAULT_CMP_TRIM  0x00u

/* PSoC5A */
#if (CY_PSOC5A)
    #define Cam_Comparator_2_CMP_TRIM1_DIR  0x08u   /* Trim direction for N-type load for offset calibration */
    #define Cam_Comparator_2_CMP_TRIM1_MASK 0x07u   /* Trim for N-type load for offset calibration */
    #define Cam_Comparator_2_CMP_TRIM2_DIR  0x80u   /* Trim direction for P-type load for offset calibration */
    #define Cam_Comparator_2_CMP_TRIM2_MASK 0x70u   /* Trim for P-type load for offset calibration */
#endif /* CY_PSOC5A */

/* PSoC3, PSoC5LP or later */
#if (CY_PSOC3 || CY_PSOC5LP)
    #define Cam_Comparator_2_CMP_TR0_DIR 0x10u    /* Trim direction for N-type load for offset calibration */
    #define Cam_Comparator_2_CMP_TR0_MASK 0x0Fu   /* Trim for N-type load for offset calibration */
    #define Cam_Comparator_2_CMP_TR1_DIR 0x10u    /* Trim direction for P-type load for offset calibration */
    #define Cam_Comparator_2_CMP_TR1_MASK 0x07u   /* Trim for P-type load for offset calibration */ 
#endif /* CY_PSOC3 || CY_PSOC5LP */


/* WRK (Comp output working register)     */ 
#define Cam_Comparator_2_CMP_OUT_MASK   Cam_Comparator_2_ctComp__WRK_MASK /* Specific comparator out mask */

/* PM_ACT_CFG7 (Active Power Mode CFG Register)     */ 
#define Cam_Comparator_2_ACT_PWR_EN     Cam_Comparator_2_ctComp__PM_ACT_MSK /* Power enable mask */

/* PM_STBY_CFG7 (Standby Power Mode CFG Register)     */ 
#define Cam_Comparator_2_STBY_PWR_EN     Cam_Comparator_2_ctComp__PM_STBY_MSK /* Standby Power enable mask */

#if (CY_PSOC5A)
    /* For stop API changes mask to make the COMP register CR to 0X00  */
    #define Cam_Comparator_2_COMP_REG_CLR             (0x00u)
#endif /* CY_PSOC5A */

#endif /* CY_COMP_Cam_Comparator_2_H */


/* [] END OF FILE */
